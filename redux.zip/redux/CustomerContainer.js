import React , {Component} from 'react';
import {connect} from 'react-redux';
import { fetchUsers } from './customer/customerActions';

// export class CustomerContainer extends